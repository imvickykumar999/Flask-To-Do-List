# Django Ajax CRUD

```bash
unzip /home/ajaxtodolist/todoproject/app.zip
pip install -r requirements.txt
find /home/ajaxtodolist -type d -exec chmod 755 {} +
zip -r project.zip .

```
![image](https://github.com/user-attachments/assets/2e4ae934-1a86-4f55-9dde-612c164846ea)
![image](https://github.com/user-attachments/assets/7f7db17f-a07e-42a8-bb62-e79cda190862)
![image](https://github.com/user-attachments/assets/ec11bab7-dd1d-4ae7-b106-86b5b5237364)
