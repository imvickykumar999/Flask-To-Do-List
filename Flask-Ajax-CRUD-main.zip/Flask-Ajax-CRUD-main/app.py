from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///tasks.db'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
db = SQLAlchemy(app)

# Define Task model with photo
class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    is_completed = db.Column(db.Boolean, default=False)
    user_id = db.Column(db.Integer)
    photo = db.Column(db.String(100))  # Field to store photo filename/path

# Index route
@app.route('/')
def index():
    return render_template('index.html')

# Get tasks for a specific user
@app.route('/get_tasks', methods=['GET'])
def get_tasks():
    tasks = Task.query.filter_by(user_id=1).order_by(Task.is_completed).all()  # User logic placeholder
    tasks_json = [
        {
            'id': task.id, 
            'name': task.name, 
            'is_completed': task.is_completed, 
            'photo': url_for('static', filename='uploads/' + task.photo) if task.photo else None
        } for task in tasks]
    return jsonify({'tasks': tasks_json})

# Add task with photo upload
@app.route('/add_task', methods=['POST'])
def add_task():
    task_name = request.form.get('name')
    file = request.files.get('photo')  # Get the uploaded file
    if task_name and file:
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        new_task = Task(name=task_name, user_id=1, photo=filename)  # Replace 1 with actual user logic
        db.session.add(new_task)
        db.session.commit()
        return jsonify({
            'task': {'id': new_task.id, 'name': new_task.name, 'is_completed': new_task.is_completed, 'photo': new_task.photo}
        })
    return jsonify({'error': 'Task name and photo are required'}), 400

# Update task with photo upload
@app.route('/update_task/<int:task_id>', methods=['POST'])
def update_task(task_id):
    task = Task.query.get_or_404(task_id)
    task_name = request.form.get('name')
    task_is_completed = request.form.get('is_completed') == 'true'

    if task_name:
        task.name = task_name
    task.is_completed = task_is_completed
        
    db.session.commit()
    return jsonify({'task': {'id': task.id, 'name': task.name, 'is_completed': task.is_completed, 'photo': task.photo}})

# Delete task
@app.route('/delete_task/<int:task_id>', methods=['POST'])
def delete_task(task_id):
    task = Task.query.get_or_404(task_id)
    db.session.delete(task)
    db.session.commit()
    return jsonify({'result': 'Task deleted successfully'})

if __name__ == '__main__':
    app.run(debug=True)

